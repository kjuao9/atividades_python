altura = float(input("Qual a sua altura ?"))
peso = (72.7 * altura)-58
print("O seu peso ideal deveria ser:",peso,"kg")

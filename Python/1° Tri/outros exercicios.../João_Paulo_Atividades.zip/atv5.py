cen = float(input("Digite centímetros"))
pol = cen * 0.39
print("Medida igual a",pol,"polegadas")

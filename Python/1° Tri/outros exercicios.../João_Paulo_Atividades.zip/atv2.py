n = float(input("Digite numero:"))
print("O número informado foi",n,)

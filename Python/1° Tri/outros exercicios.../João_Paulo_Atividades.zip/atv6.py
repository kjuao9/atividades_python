r = float(input("Digite raio do círculo"))
area = 3.14 *r ** 2
print("Area igual a",area,"cm²")          

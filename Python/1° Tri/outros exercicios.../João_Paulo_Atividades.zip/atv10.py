far = float(input("Qual a temperatura em graus Farenheit?"))
c = (5 * (far - 32)/9)
print("A temperatura é igual a",c,"graus Celsius")

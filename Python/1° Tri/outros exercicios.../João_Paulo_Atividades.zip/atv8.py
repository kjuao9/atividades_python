gph = float(input("Quanto você ganha por hora ?"))
nht = float(input("Número de horas trabalhadas por mês?"))
sal = gph * nht
print("Você ganha",sal,"R$ por mês")            

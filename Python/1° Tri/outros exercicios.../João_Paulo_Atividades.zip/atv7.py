com = float(input("Digite o comprimento do quadrado em cm"))
lar = float(input("Digite a largura do quadrado em cm"))
area = com * lar
res = area * 2
print("O resultado da operação foi",res,"cm²")

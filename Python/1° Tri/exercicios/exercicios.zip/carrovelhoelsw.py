idade = int(input("Digite a idade de seua carro: "))
if idade <= 3:
    print("Seu carro é novo")
else:
    print("Seu carro é velho")

tam = float(input("Qual é o tamanho em m² a serem pintados ?"))
cob = tam / 3


cartao = input("Você tem cartão ?")
tipo = input("Qual o tipo de carne comprada ?")
quantidade = float(input("Qual a quantidade de carne comprada ?"))
desconto = 0
if cartao == "sim":
    desconto = 5
else:
    desconto = 0
if tipo == "contra file":
    if quantidade <= 5:
        preçot = quantidade * 35
        if cartao == "sim":
            desconto = 5
        else:
            desconto = 0
            vpaga = preçot / 100 * desconto
print("Tipo de carne = Contra Filé")
print("Quantidade =",quantidade,)
print("Preço total = )
   
  

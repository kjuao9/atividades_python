from random import randint
tupla = (randint(1,100),(randint(1,100),(randint(1,100),(randint(1,100),(randint(1,100))

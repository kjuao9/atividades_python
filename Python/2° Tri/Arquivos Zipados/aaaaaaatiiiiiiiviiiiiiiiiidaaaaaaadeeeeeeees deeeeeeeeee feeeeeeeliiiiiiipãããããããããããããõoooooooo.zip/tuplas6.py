palavras = ("vinho","vitamina","cerveja","rum")
palavra = "vinho"
print(palavra)
for letra in palavra:
    if letra in "aeiou":
        print(letra)
print("---------------------------------------------------------------------------------------")

palavra = "vitamina"
print(palavra)
for letra in palavra:
    if letra in "aeiou":
        print(letra)
print("---------------------------------------------------------------------------------------------")

palavra = "cerveja"
print(palavra)
for letra in palavra:
    if letra in "aeiou":
        print(letra)
print("---------------------------------------------------------------------------------------------------")

palavra = "rum"
print(palavra)
for letra in palavra:
    if letra in "aeiou":
        print(letra)
print("-------------------------------------------------------------------------------------------------")
        
        




# Atividade 1: Tuplas
tupla = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
numero = int(input("Digite um numero entre 0 e 20"))
if numero < 0 or numero > 20:
   numero = int(input("DIGITE UM NÚMERO MAIOR OU IGUAL A ZERO OU MENOR OU IGUAL À 20"))
if numero == 0:
    print("zero")
if numero == 1:
    print("um")
if numero == 2:
    print("dois")
if numero == 3:
    print("tres")
if numero == 4:
    print("quatro")
if numero == 5:
    print("cinco")
if numero == 6:
    print("seis")
if numero == 7:
    print("sete")
if numero == 8:
    print("oito")
if numero == 9:
    print("nove")
if numero == 10:
    print("dez")
if numero == 11:
    print("onze")
if numero == 12:
    print("doze")
if numero == 13:
    print("treze")
if numero == 14:
    print("catorze")
if numero == 15:
    print("quinze")
if numero == 16:
    print("dezesseis")
if numero == 17:
    print("dezessete")
if numero == 18:
    print("dezoito")
if numero == 19:
    print("dezenove")
if numero == 20:
    print("vinte")
    

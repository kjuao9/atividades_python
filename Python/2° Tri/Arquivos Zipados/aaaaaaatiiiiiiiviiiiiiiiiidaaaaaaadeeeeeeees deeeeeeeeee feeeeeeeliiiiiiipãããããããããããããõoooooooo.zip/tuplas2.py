times = ("São Paulo","Flamengo","Internacional","Grêmio","Atlético-MG","Palmeiras","Corinthians","Cruzeiro","Fluminense","América-MG","Botafogo","Sport","Vasco","Vitória","Bahia","Chapecoense","Santos","Atlético-PR","Ceará","Paraná")
print("Os cinco primeiros times são:",.index(0))

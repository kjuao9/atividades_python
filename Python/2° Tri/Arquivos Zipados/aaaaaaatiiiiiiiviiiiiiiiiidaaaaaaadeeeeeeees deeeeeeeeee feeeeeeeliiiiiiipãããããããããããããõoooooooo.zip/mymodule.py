coisas = {
  "pindamonhagaba": "pinga com goiaba",
  "sergipe": "ser jipe",
  "bocaiuva": "boca e uva"
}

import mymodule

p = mymodule.coisas["pindamonhagaba"]
s = mymodule.coisas["sergipe"]
b = mymodule.coisas["bocaiuva"]

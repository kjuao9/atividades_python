while True:
	nome = input('Digite seu nome: ')
	if nome == 'seu nome':
		break
print('Obrigado!')

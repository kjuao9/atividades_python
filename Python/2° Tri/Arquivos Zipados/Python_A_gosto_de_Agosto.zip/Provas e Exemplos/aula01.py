Python 3.5.2 (default, Nov 17 2016, 17:05:23) 
[GCC 5.4.0 20160609] on linux
Type "copyright", "credits" or "license()" for more information.
>>> x = IFNMG
Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    x = IFNMG
NameError: name 'IFNMG' is not defined
>>> x = ifnmg
Traceback (most recent call last):
  File "<pyshell#1>", line 1, in <module>
    x = ifnmg
NameError: name 'ifnmg' is not defined
>>> a =
SyntaxError: invalid syntax
>>> a = joao
Traceback (most recent call last):
  File "<pyshell#3>", line 1, in <module>
    a = joao
NameError: name 'joao' is not defined
>>> a = (joao)
Traceback (most recent call last):
  File "<pyshell#4>", line 1, in <module>
    a = (joao)
NameError: name 'joao' is not defined
>>> a = "joao"
>>> print(a)
joao
>>> type(a)
<class 'str'>
>>> print("eu sou + a)
      
SyntaxError: EOL while scanning string literal
>>> print("eu sou + a")
eu sou + a
>>> a * a
Traceback (most recent call last):
  File "<pyshell#10>", line 1, in <module>
    a * a
TypeError: can't multiply sequence by non-int of type 'str'
>>> 5 * 5
25
>>> 2**3
8
>>> 2**
SyntaxError: invalid syntax
>>> 2*******9
SyntaxError: invalid syntax
>>> 9**9
387420489
>>> 5*6
30
>>> 5**6
15625
>>> 5**5
3125
>>> 1**1
1
>>> 0**0
1
>>> 2**3
8
>>> 2**2
4
>>> 2**9
512
>>> 22//8
2
>>> 22%8
6
>>> 540%5
0
>>> 540%9
0
>>> 549%7
3
>>> 49**(.5)
7.0
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 666**(.5)
25.80697580112788
>>> 
>>> 

>>> 
>>> 
>>> 666**(1/3)
8.732891741295965
>>> j = k =89
>>> j
89
>>> k
89
>>> '''jnlnjsgfd
gfdgdfgdfg
fdgfdgfdg
jojpdajds
'''
'jnlnjsgfd\ngfdgdfgdfg\nfdgfdgfdg\njojpdajds\n'
>>> huehuehuehuehue
Traceback (most recent call last):
  File "<pyshell#96>", line 1, in <module>
    huehuehuehuehue
NameError: name 'huehuehuehuehue' is not defined
>>> '''huehuehuehuehuehue
huehuehuehuehuehuehue
huehuehuehuehuehue
'''
'huehuehuehuehuehue\nhuehuehuehuehuehuehue\nhuehuehuehuehuehue\n'
>>> 

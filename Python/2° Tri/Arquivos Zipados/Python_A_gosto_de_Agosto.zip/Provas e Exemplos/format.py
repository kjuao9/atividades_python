nome =input("seu nome")
idade = 15
print("Eu me chamo {} e tenho {} anos." .format(nome, idade))

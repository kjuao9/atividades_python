a = []
a.append[5]
a.append[7]
b = list()
b.append(13)
b.append(42)
c = b
c = a[:]

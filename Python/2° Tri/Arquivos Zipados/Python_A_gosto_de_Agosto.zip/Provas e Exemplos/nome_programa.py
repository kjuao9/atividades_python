nome = input("Digite seu nome:")
print("Voce digitou ",nome)
ano = int(input("Digite ano que voce nasceu: "))
idade = 2018 - ano
print("Ola ",nome," sua idade é ",idade)

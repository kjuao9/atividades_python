Python 3.5.2 (default, Nov 17 2016, 17:05:23) 
[GCC 5.4.0 20160609] on linux
Type "copyright", "credits" or "license()" for more information.
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Deseja imprimir até quanto:10
55
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Deseja imprimir até quanto:100
5050
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Deseja imprimir até quanto:1000
500500
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/12.py ====

    1 - Somar
    2 - Subtrair
    3 - Dividir
    4 - Multiplicar
    5 - Sair
    
Escolha uma opçao5
Desligando
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/12.py ====

    1 - Somar
    2 - Subtrair
    3 - Dividir
    4 - Multiplicar
    5 - Sair
    
Escolha uma opçao1
Primeiro Número15
Segundo Número20
O resultado é 35

    1 - Somar
    2 - Subtrair
    3 - Dividir
    4 - Multiplicar
    5 - Sair
    
Escolha uma opçao3
Primeiro Número12
Segundo Número3
O resultado é 4.0

    1 - Somar
    2 - Subtrair
    3 - Dividir
    4 - Multiplicar
    5 - Sair
    
Escolha uma opçao4
Primeiro Número5
Segundo Número5
O resultado é 25

    1 - Somar
    2 - Subtrair
    3 - Dividir
    4 - Multiplicar
    5 - Sair
    
Escolha uma opçao2
Primeiro Número90
Segundo Número30
O resultado é 60

    1 - Somar
    2 - Subtrair
    3 - Dividir
    4 - Multiplicar
    5 - Sair
    
Escolha uma opçao5
Desligando
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:5
Digite o valor do produto12
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Traceback (most recent call last):
  File "/home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py", line 2, in <module>
    while x <pc:
NameError: name 'x' is not defined
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:4
Digite o valor do produto3
Digite o valor do produto4
Digite o valor do produto6
Digite o valor do produto
Traceback (most recent call last):
  File "/home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py", line 4, in <module>
    int(input("Digite o valor do produto"))
ValueError: invalid literal for int() with base 10: ''
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:4
Digite o valor do produto6
Digite o valor do produto8
Digite o valor do produto5
Digite o valor do produto4
Digite o valor do produto65
Digite o valor do produto65
Digite o valor do produto28
Digite o valor do produto48
Digite o valor do produto185
Digite o valor do produto
Traceback (most recent call last):
  File "/home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py", line 4, in <module>
    int(input("Digite o valor do produto"))
  File "/usr/lib/python3.5/idlelib/PyShell.py", line 1386, in readline
    line = self._line_buffer or self.shell.readline()
KeyboardInterrupt
>>> print(pc)
4
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:4
Digite o valor do produto25
Digite o valor do produto19
Digite o valor do produto3
Digite o valor do produto10
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto12
Traceback (most recent call last):
  File "/home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py", line 6, in <module>
    soma +=x
NameError: name 'soma' is not defined
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:12
Digite o valor do produto1
Digite o valor do produto5
Digite o valor do produto3
Digite o valor do produto
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto10
Digite o valor do produto12
Digite o valor do produto15
3
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto12
Digite o valor do produto13
Digite o valor do produto11
6
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:2
0
1
3
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:2
Digite o valor do produto15
15
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto15
15
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto2
3
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:5
Digite o valor do produto9
10
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto12
Digite o valor do produto13
Digite o valor do produto15
Digite o valor do produto20
Digite o valor do produto15
Digite o valor do produto1546
Digite o valor do produto1563
Digite o valor do produto
Traceback (most recent call last):
  File "/home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py", line 5, in <module>
    x = int(input("Digite o valor do produto"))
  File "/usr/lib/python3.5/idlelib/PyShell.py", line 1386, in readline
    line = self._line_buffer or self.shell.readline()
KeyboardInterrupt
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto15
0
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto15
16
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto280
280
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto12
Digite o valor do produto,12
Digite o valor do produto12
12
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:12
Digite o valor do produto23
Digite o valor do produto25
Digite o valor do produto15
Digite o valor do produto752
Digite o valor do produto752
Digite o valor do produto756
Digite o valor do produto85
Digite o valor do produto287
Digite o valor do produto1
Digite o valor do produto7
Traceback (most recent call last):
  File "/home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py", line 4, in <module>
    vp = int(input("Digite o valor do produto"))
ValueError: invalid literal for int() with base 10: ''
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:
Traceback (most recent call last):
  File "/home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py", line 2, in <module>
    pc = int(input("Digite a quantidade de produtos comprados:"))
ValueError: invalid literal for int() with base 10: ''
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:
Traceback (most recent call last):
  File "/home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py", line 2, in <module>
    pc = int(input("Digite a quantidade de produtos comprados:"))
ValueError: invalid literal for int() with base 10: ''
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:
Traceback (most recent call last):
  File "/home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py", line 2, in <module>
    pc = int(input("Digite a quantidade de produtos comprados:"))
ValueError: invalid literal for int() with base 10: ''
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:12
Digite o valor do produto12
Digite o valor do produto
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto12
Digite o valor do produto13
Digite o valor do produto14
14
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto15
Digite o valor do produto20
Digite o valor do produto2
5
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:2
Digite o valor do produto10
Digite o valor do produto15
2
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite a quantidade de produtos comprados:3
Digite o valor do produto12
Digite o valor do produto15
Digite o valor do produto39
Digite o valor do produto28.6
Traceback (most recent call last):
  File "/home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py", line 4, in <module>
    vp = int(input("Digite o valor do produto"))
ValueError: invalid literal for int() with base 10: '28.6'
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite o valor do produto15
Digite o valor do produto95
Digite o valor do produto0
0
>>> 
==== RESTART: /home/info1/Área de Trabalho/Aulas Python/Nova pasta/02.py ====
Digite o valor do produto15
15
Digite o valor do produto95
95
Digite o valor do produto15
15
Digite o valor do produto54
54
Digite o valor do produto

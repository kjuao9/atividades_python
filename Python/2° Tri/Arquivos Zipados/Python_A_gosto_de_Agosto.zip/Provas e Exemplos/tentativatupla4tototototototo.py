x = 0
y = 0
z = 0 

v1 = (int(input("Digite um valor:")))
v2 = (int(input("Digite um valor:")))
v3 = (int(input("Digite um valor:")))
v4 = (int(input("Digite um valor:")))

valores = (v1,v2,v3,v4)
if 9 in valores:
    y = y + 1
    print("O nove foi digitado",y,"vez(es)")
if 3 in valores:
    z = z + 1
    print("O três foi digitado",z,"vez(es)")
    
    
    

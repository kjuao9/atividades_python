compras = ("açucar","chocolate","arroz","feijão","bolacha")
(compras)
compras[-5]
(compras)
compras[-2]
(compras)
compras[-1]
(compras)
compras[0]
(compras)
compras[4]
(compras)
compras[1:3]
(compras)
compras[:3]
(compras)
compras[2:]
(compras)
compras[-3:-1]
(compras)
compras
(compras)
compras[::2]
(compras)
numeros = [0,1,2,1,5,4,32,1,2,1,5,4,9,6,5,8,3,-3,-3,-1,0]
numeros.count(2)
numeros.count(1)
numeros.index(6)
numeros.index(2)
numeros.index(2,4)
7 in numeros
8 in numeros
len(numeros)
max(numeros)
min(numeros)
sorted(numeros)
sorted(numeros,reverse=True)
### count serve para contar quantas vezes o número aparece
### index serve para mostrar o endereço do número, com o primeiro numero sendo 0
### sorted ordena a lista do menor para o maior, e reverse=True faz o contrario

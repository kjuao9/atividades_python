a = (int(input("Digite um valor:")))
b = (int(input("Digite um valor:")))
c = (int(input("Digite um valor:")))
d = (int(input("Digite um valor:")))
x = 0
y = 0
valores = (a,b,c,d)
if 9 in valores:
    x = x + 1
    print("O número 9 foi digitado",x,"vez(es)")
if 3 in valores:
    y = y + 1
    print("O número 3 foi digitado",y,"vez(es)")

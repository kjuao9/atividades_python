# Atividade 1: Tuplas
tupla = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
numero = int(input("Digite um numero entre 0 e 20"))
if numero < 0 or numero > 20:
   numero = int(input("DIGITE UM NÚMERO MAIOR OU IGUAL A ZERO OU MENOR OU IGUAL À 20"))
if numero == 0:
    print("zero")
elif numero == 1:
    print("um")
elif numero == 2:
    print("dois")
elif numero == 3:
    print("tres")
elif numero == 4:
    print("quatro")
elif numero == 5:
    print("cinco")
elif numero == 6:
    print("seis")
elif numero == 7:
    print("sete")
elif numero == 8:
    print("oito")
elif numero == 9:
    print("nove")
elif numero == 10:
    print("dez")
elif numero == 11:
    print("onze")
elif numero == 12:
    print("doze")
elif numero == 13:
    print("treze")
elif numero == 14:
    print("catorze")
elif numero == 15:
    print("quinze")
elif numero == 16:
    print("dezesseis")
elif numero == 17:
    print("dezessete")
elif numero == 18:
    print("dezoito")
elif numero == 19:
    print("dezenove")
elif numero == 20:
    print("vinte")
    

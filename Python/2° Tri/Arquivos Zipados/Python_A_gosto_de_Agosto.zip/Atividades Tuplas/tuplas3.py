import random
x = 0
a = random.randint(0,100)
b = random.randint(0,100)
c = random.randint(0,100)
d = random.randint(0,100)
e = random.randint(0,100)
tupla = (a,b,c,d,e)
print(tupla)
print("O maior número é:",max(tupla))
print("E o menor número é:",min(tupla))

tam = float(input("Qual é o tamanho em m² a serem pintados ?"))
if tam > 50:
    print("tamanho")


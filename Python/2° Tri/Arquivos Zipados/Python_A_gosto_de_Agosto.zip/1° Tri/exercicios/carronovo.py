idade = float(input("Quantos anos tem seu carro ?"))
if idade <= 3:
    print("Seu carro é novo")
    print("Parabens !")

if idade > 3:
    print("Seu carro é velho")
    print("Sinto Muito!")
print("Tchau.")

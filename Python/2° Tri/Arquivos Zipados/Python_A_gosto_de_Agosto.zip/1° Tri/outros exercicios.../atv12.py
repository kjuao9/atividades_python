n1 = input("Qual o primeiro numero inteiro?")
n1 = int(n1)
n2 = input("Qual o segundo numero inteiro?")
n2 = int(n2)
n3 = float(input("Qual o numero real?"))
a = (n1 * 2)*(n2/2)
print("O produto do dobro do primeiro com metade do segundo é igual a:",a)
b = (3 * n1)+ n3
print("A soma do triplo do primeiro com o terceiro é igual a:",b)
c = n3*n3*n3
print("O terceiro elevado ao cubo é igual a:",c)


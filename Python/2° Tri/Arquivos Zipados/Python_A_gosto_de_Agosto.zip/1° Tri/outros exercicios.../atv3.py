n1 = float(input("Digite o 1° número:"))
n2 = float(input("Digite o 2° número:"))
print("A soma dos dois números foi", n1 + n2)

cel = float(input("Qual a temperatura em graus Celsius?"))
far = cel / 5 * 9 + 32
print("A temperatura é igual a",far,"graus Farenheit")


 

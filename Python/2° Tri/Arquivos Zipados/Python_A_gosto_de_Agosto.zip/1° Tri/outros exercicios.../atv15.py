k = float(input("Quantos kilometros voce percorreu com o carro?"))
d = float(input("Por quantos dias o carro foi alugado?"))
p = (60 * d)+(0.15 * k)
print("O preço a ser pago e:",p,"R$")

tipo = input("Digite o tipo de carne comprada :")
quantidade = float(int("Digite a quantidade de carne comprada :"))
if quantidade

x = 0
soma = 0
while x < 51:
    print(x)
    soma +=x
    x += 2
print("A soma dos números pares menores que 50 é:",soma)

n = int(input("Digite um número inteiro não negativo"))
for x in range(n,0,-1):
    v = n * x
    v = v 
    print(v)




pl = 0
ii = 0
im = 0
while pl < 10:
    i = int(input("Digite a idade do membro"))
    pl = pl + 1
    if i < 30:
        ii = ii + 1
        im = i/10
print(ii,"membro(s) tem a idade inferior a 30 anos")

        
        
